const out = document.getElementById("out");
document.getElementById("btn").addEventListener("click", async () => {
  out.textContent = "Loading...";
  const body = {
    latitude: Number(document.getElementById("lat").value),
    longitude: Number(document.getElementById("lon").value),
    hours: Number(document.getElementById("hours").value),
  };
  try {
    const res = await fetch("/analyze", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(body),
    });
    const json = await res.json();
    out.textContent = JSON.stringify(json, null, 2);
  } catch (e) {
    out.textContent = "Error: " + e;
  }
});
