import logging
import time
import uuid
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from service.routes import router

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
log = logging.getLogger("air_insights")

app = FastAPI(title="Air & Insights Copilot", version="0.1.0")
app.include_router(router)

# --- Simple request logging middleware ---
@app.middleware("http")
async def request_logging(request: Request, call_next):
    rid = str(uuid.uuid4())
    t0 = time.perf_counter()
    response = None
    try:
        response = await call_next(request)
        return response
    finally:
        dt_ms = (time.perf_counter() - t0) * 1000.0
        status = getattr(response, "status_code", "NA")
        log.info("rid=%s method=%s path=%s status=%s ms=%.1f", rid, request.method, request.url.path, status, dt_ms)
        if response is not None:
            response.headers["X-Request-ID"] = rid


# --- Serve minimal demo UI from ui/web ---
BASE_DIR = Path(__file__).resolve().parent.parent
UI_DIR = BASE_DIR / "ui" / "web"

if UI_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(UI_DIR)), name="static")

    @app.get("/")
    async def ui_index():
        return FileResponse(UI_DIR / "index.html")
