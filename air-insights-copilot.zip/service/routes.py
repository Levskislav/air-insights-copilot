import logging

from fastapi import APIRouter, HTTPException
from service.schemas import AnalyzeRequest, AnalyzeResponse, ApodResponse
from agent.orchestrator import analyze_air_and_weather, apod_today

log = logging.getLogger("air_insights")

router = APIRouter()


@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze(req: AnalyzeRequest):
    try:
        return await analyze_air_and_weather(req.latitude, req.longitude, req.hours)
    except ValueError as e:
        # validation errors
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        log.exception("analyze failed")
        raise HTTPException(status_code=502, detail="Upstream unavailable or processing error") from e


@router.get("/apod/today", response_model=ApodResponse)
async def apod():
    try:
        return await apod_today()
    except Exception as e:
        log.exception("apod failed")
        raise HTTPException(status_code=502, detail="Upstream unavailable or processing error") from e
