from pydantic import BaseModel, Field


class AnalyzeRequest(BaseModel):
    latitude: float
    longitude: float
    hours: int = Field(ge=1, le=72)


class AnalyzeResponse(BaseModel):
    pm25_avg: float | None
    pm10_avg: float | None
    temp_avg: float | None
    guidance_text: str


class ApodResponse(BaseModel):
    title: str
    url: str
    explanation: str
