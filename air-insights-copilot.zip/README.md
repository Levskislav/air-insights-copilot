# Agentic “Air & Insights Copilot”

An **agentic assistant service** that:
- fetches **air quality** (PM2.5, PM10) and **temperature** for the next *N* hours from **Open-Meteo** (no API key),
- optionally fetches **NASA APOD**,
- uses **GitHub Models (free inference)** to produce **actionable guidance** (e.g., “Is it safe to run outdoors?”),
- exposes a **REST API + OpenAPI 3.0** that can be wired into **Microsoft Copilot Studio** (Track A) or used with a free UI (Track B).

**Attribution requirement:** responses include: `Weather data by Open-Meteo.com`

---

## Quick start (local)

### 1) Install
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2) Configure
Copy `.env.example` to `.env` and set:
- `GITHUB_MODELS_TOKEN`
- `GITHUB_MODELS_MODEL`
Optional:
- `NASA_API_KEY=DEMO_KEY` (works for demo)

### 3) Run
```bash
uvicorn service.main:app --reload --port 8000
```

Open Swagger UI:
- http://localhost:8000/docs

Open demo UI:
- http://localhost:8000/

---

## API

### POST /analyze
Request:
```json
{ "latitude": 42.6977, "longitude": 23.3219, "hours": 6 }
```

Response:
```json
{
  "pm25_avg": 12.3,
  "pm10_avg": 18.1,
  "temp_avg": 6.7,
  "guidance_text": "..."
}
```

### GET /apod/today (optional)
Returns:
```json
{ "title": "...", "url": "...", "explanation": "..." }
```

---

## Demo prompts (for Copilot or your UI)
- “What’s the PM2.5 and temperature around 42.6977, 23.3219 for the next 6 hours and should I run outdoors?”
- “Show today’s NASA APOD and summarize in 2 lines.”

---

## Copilot Studio (Track A) wiring

1) Deploy this service to a public HTTPS URL  
2) Export OpenAPI:
```bash
curl -s https://<your-host>/openapi.json > service/openapi.json
```
3) In Copilot Studio: Add Tool → REST API, import the OpenAPI file, keep **Generative Orchestration ON**  
4) Use the snippet in `docs/copilot_tool_snippet.md` for a good tool description  
5) Take screenshots (tool config + chat calling the tool)

---

## Repo layout
- `service/` – FastAPI service + OpenAPI export
- `agent/` – orchestration (planner, validation, caching, LLM)
- `ui/web/` – minimal browser UI
- `tests/` – unit + integration tests (stubbed external calls)
- `docs/` – project plan, technical execution steps, Copilot snippet, runbook
