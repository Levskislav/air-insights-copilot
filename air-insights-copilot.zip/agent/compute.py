def safe_avg(values: list[float | None] | None) -> float | None:
    """Compute an average, safely handling None / missing values."""
    if not values:
        return None
    nums = [v for v in values if v is not None]
    if not nums:
        return None
    return sum(nums) / len(nums)
