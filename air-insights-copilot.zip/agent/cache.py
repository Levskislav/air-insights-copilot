import os
from cachetools import TTLCache

TTL = int(os.getenv("CACHE_TTL_SECONDS", "600"))
_cache = TTLCache(maxsize=1024, ttl=TTL)


def cache_key(lat: float, lon: float, hours: int) -> str:
    # Reduce cache fragmentation by rounding coordinates.
    return f"{round(lat, 4)}:{round(lon, 4)}:{hours}"


def cache_get(key: str):
    return _cache.get(key)


def cache_set(key: str, value):
    _cache[key] = value


def cache_clear():
    _cache.clear()
