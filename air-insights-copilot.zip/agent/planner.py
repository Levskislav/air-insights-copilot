def plan_for_analyze(lat: float, lon: float, hours: int) -> dict:
    """Minimal planner.

    Kept as a separate step to preserve 'agentic feel' and allow future expansion
    (e.g., air-only, weather-only, etc.).
    """
    return {
        "need_air": True,
        "need_weather": True,
        "air_vars": ["pm2_5", "pm10"],
        "weather_vars": ["temperature_2m"],
    }
