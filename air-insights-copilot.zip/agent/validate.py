from dataclasses import dataclass


@dataclass
class QualityFlags:
    sparse_air: bool = False
    sparse_weather: bool = False
    missing_fields: list[str] | None = None


def validate_lat_lon(lat: float, lon: float) -> None:
    if lat < -90 or lat > 90:
        raise ValueError("latitude out of range [-90..90]")
    if lon < -180 or lon > 180:
        raise ValueError("longitude out of range [-180..180]")


def _get_hourly_array(payload: dict, key: str):
    hourly = payload.get("hourly") if isinstance(payload, dict) else None
    if not hourly or key not in hourly:
        return None
    arr = hourly.get(key)
    return arr if isinstance(arr, list) else None


def validate_open_meteo_payload(air_json: dict | None, wx_json: dict | None, hours: int):
    flags = QualityFlags(missing_fields=[])

    pm25 = pm10 = temp = None

    if air_json:
        pm25 = _get_hourly_array(air_json, "pm2_5")
        pm10 = _get_hourly_array(air_json, "pm10")
        if pm25 is None:
            flags.missing_fields.append("pm2_5")
        if pm10 is None:
            flags.missing_fields.append("pm10")
        flags.sparse_air = (not pm25) or (len(pm25) < 1)

    if wx_json:
        temp = _get_hourly_array(wx_json, "temperature_2m")
        if temp is None:
            flags.missing_fields.append("temperature_2m")
        flags.sparse_weather = (not temp) or (len(temp) < 1)

    # Slice to requested window (best-effort)
    if pm25:
        pm25 = pm25[:hours]
    if pm10:
        pm10 = pm10[:hours]
    if temp:
        temp = temp[:hours]

    return {"pm25": pm25, "pm10": pm10, "temp": temp}, flags
