import logging
import time

import agent.cache as cache
import agent.planner as planner
import agent.validate as validate
from agent.compute import safe_avg
import agent.tools.open_meteo as open_meteo
import agent.tools.github_models_llm as gh_llm
import agent.tools.nasa_apod as nasa_apod

log = logging.getLogger("air_insights")

ATTRIBUTION = "Weather data by Open-Meteo.com"


async def analyze_air_and_weather(lat: float, lon: float, hours: int) -> dict:
    """Agentic flow: plan → cache → fetch → validate → compute → LLM → cache → respond."""
    validate.validate_lat_lon(lat, lon)

    key = cache.cache_key(lat, lon, hours)
    cached = cache.cache_get(key)
    if cached:
        return cached

    plan = planner.plan_for_analyze(lat, lon, hours)

    t0 = time.perf_counter()
    air_json = await open_meteo.fetch_air_quality(lat, lon, hours) if plan.get("need_air") else None
    t_air = (time.perf_counter() - t0) * 1000.0

    t1 = time.perf_counter()
    wx_json = await open_meteo.fetch_weather(lat, lon, hours) if plan.get("need_weather") else None
    t_wx = (time.perf_counter() - t1) * 1000.0

    data, flags = validate.validate_open_meteo_payload(air_json, wx_json, hours)

    pm25_avg = safe_avg(data.get("pm25"))
    pm10_avg = safe_avg(data.get("pm10"))
    temp_avg = safe_avg(data.get("temp"))

    t2 = time.perf_counter()
    guidance = await gh_llm.generate_guidance_text(
        pm25_avg=pm25_avg,
        pm10_avg=pm10_avg,
        temp_avg=temp_avg,
        hours=hours,
        lat=lat,
        lon=lon,
        flags=flags,
    )
    t_llm = (time.perf_counter() - t2) * 1000.0

    guidance = (guidance or "").strip()
    if ATTRIBUTION not in guidance:
        guidance = guidance + ("\n\n" if guidance else "") + ATTRIBUTION

    resp = {
        "pm25_avg": pm25_avg,
        "pm10_avg": pm10_avg,
        "temp_avg": temp_avg,
        "guidance_text": guidance,
    }

    cache.cache_set(key, resp)

    log.info("timings air_ms=%.1f wx_ms=%.1f llm_ms=%.1f cache_key=%s", t_air, t_wx, t_llm, key)
    return resp


async def apod_today() -> dict:
    apod = await nasa_apod.fetch_apod_today()
    return {
        "title": apod.get("title", ""),
        "url": apod.get("url", ""),
        "explanation": apod.get("explanation", ""),
    }
