import asyncio
from typing import Any

import httpx

RETRY_STATUS = {429, 500, 502, 503, 504}


async def request_with_retry(
    method: str,
    url: str,
    *,
    params: dict | None = None,
    headers: dict | None = None,
    json: dict | None = None,
    timeout: float = 1.0,
) -> Any:
    """HTTP request with retry/backoff for transient errors.

    Retries on: 429, 500, 502, 503, 504 and network exceptions.
    """
    delays = [0.2, 0.5, 1.2]
    last_err: Exception | None = None

    for i in range(len(delays) + 1):
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                r = await client.request(method, url, params=params, headers=headers, json=json)

            if r.status_code in RETRY_STATUS:
                raise RuntimeError(f"retryable http status {r.status_code}")

            r.raise_for_status()
            return r.json()

        except Exception as e:
            last_err = e
            if i < len(delays):
                await asyncio.sleep(delays[i])
            else:
                raise last_err
