import os
from agent.retry import request_with_retry

APOD_URL = "https://api.nasa.gov/planetary/apod"


async def fetch_apod_today() -> dict:
    key = os.getenv("NASA_API_KEY", "DEMO_KEY")
    params = {"api_key": key}
    timeout = float(os.getenv("HTTP_TIMEOUT_SECONDS", "1.0"))
    return await request_with_retry("GET", APOD_URL, params=params, timeout=timeout)
