import os
from agent.retry import request_with_retry

GITHUB_URL = "https://models.github.ai/inference/chat/completions"


def _load(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _build_messages(*, pm25_avg, pm10_avg, temp_avg, hours, lat, lon, flags):
    system = _load("agent/prompts/guidance_system.txt")
    user_tmpl = _load("agent/prompts/guidance_user_template.txt")
    user = user_tmpl.format(
        lat=lat,
        lon=lon,
        hours=hours,
        pm25=pm25_avg,
        pm10=pm10_avg,
        temp=temp_avg,
        sparse_air=flags.sparse_air,
        sparse_weather=flags.sparse_weather,
        missing_fields=",".join(flags.missing_fields or []),
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]


def fallback_guidance(*, pm25_avg, pm10_avg, temp_avg, hours, flags) -> str:
    # Simple (non-medical) fallback when LLM is unavailable.
    parts = [f"Window: next {hours} hours."]
    if pm25_avg is None or temp_avg is None:
        parts.append("Data is incomplete; consider a cautious approach or check again later.")
    else:
        parts.append("If the air feels irritating, consider lowering intensity or shortening the run.")
    parts.append("If you feel unwell, stop and move indoors.")
    if flags.missing_fields:
        parts.append(f"Missing fields: {', '.join(flags.missing_fields)}.")
    return " ".join(parts)


async def generate_guidance_text(*, pm25_avg, pm10_avg, temp_avg, hours, lat, lon, flags) -> str:
    token = os.getenv("GITHUB_MODELS_TOKEN")
    model = os.getenv("GITHUB_MODELS_MODEL")
    if not token or not model or token == "replace_me" or model == "replace_me":
        return fallback_guidance(pm25_avg=pm25_avg, pm10_avg=pm10_avg, temp_avg=temp_avg, hours=hours, flags=flags)

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    body = {
        "model": model,
        "messages": _build_messages(
            pm25_avg=pm25_avg,
            pm10_avg=pm10_avg,
            temp_avg=temp_avg,
            hours=hours,
            lat=lat,
            lon=lon,
            flags=flags,
        ),
        "temperature": 0.3,
    }
    timeout = float(os.getenv("LLM_TIMEOUT_SECONDS", "1.5"))
    try:
        resp = await request_with_retry("POST", GITHUB_URL, headers=headers, json=body, timeout=timeout)
        return resp["choices"][0]["message"]["content"]
    except Exception:
        return fallback_guidance(pm25_avg=pm25_avg, pm10_avg=pm10_avg, temp_avg=temp_avg, hours=hours, flags=flags)
