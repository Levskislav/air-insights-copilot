import os
from agent.retry import request_with_retry

AIR_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"
WX_URL = "https://api.open-meteo.com/v1/forecast"


async def fetch_air_quality(lat: float, lon: float, hours: int) -> dict:
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": "pm2_5,pm10",
        # Open-Meteo supports forecast_hours to control hourly timesteps
        "forecast_hours": hours,
        "timezone": "auto",
    }
    timeout = float(os.getenv("HTTP_TIMEOUT_SECONDS", "1.0"))
    return await request_with_retry("GET", AIR_URL, params=params, timeout=timeout)


async def fetch_weather(lat: float, lon: float, hours: int) -> dict:
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": "temperature_2m",
        "forecast_hours": hours,
        "timezone": "auto",
    }
    timeout = float(os.getenv("HTTP_TIMEOUT_SECONDS", "1.0"))
    return await request_with_retry("GET", WX_URL, params=params, timeout=timeout)
