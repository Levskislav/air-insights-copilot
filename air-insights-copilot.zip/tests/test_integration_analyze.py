from fastapi.testclient import TestClient

from service.main import app
import agent.cache as cache
import agent.tools.open_meteo as open_meteo
import agent.tools.github_models_llm as gh_llm


async def fake_air_quality(lat, lon, hours):
    return {"hourly": {"pm2_5": [10, 20], "pm10": [15, 25]}}


async def fake_weather(lat, lon, hours):
    return {"hourly": {"temperature_2m": [5, 7]}}


async def fake_guidance_text(**kwargs):
    return "Looks reasonable. Consider a moderate pace and reassess if conditions worsen."


def test_analyze_integration(monkeypatch):
    # Ensure cache doesn't short-circuit patched functions
    cache.cache_clear()

    monkeypatch.setattr(open_meteo, "fetch_air_quality", fake_air_quality)
    monkeypatch.setattr(open_meteo, "fetch_weather", fake_weather)
    monkeypatch.setattr(gh_llm, "generate_guidance_text", fake_guidance_text)

    client = TestClient(app)
    r = client.post("/analyze", json={"latitude": 42.6977, "longitude": 23.3219, "hours": 2})
    assert r.status_code == 200
    data = r.json()
    assert data["pm25_avg"] is not None
    assert "Weather data by Open-Meteo.com" in data["guidance_text"]
