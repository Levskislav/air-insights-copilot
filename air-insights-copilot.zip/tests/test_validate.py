import pytest
from agent.validate import validate_lat_lon


def test_lat_lon_ok():
    validate_lat_lon(42.0, 23.0)


def test_lat_out_of_range():
    with pytest.raises(ValueError):
        validate_lat_lon(200.0, 23.0)


def test_lon_out_of_range():
    with pytest.raises(ValueError):
        validate_lat_lon(42.0, 200.0)
