from agent.compute import safe_avg


def test_safe_avg_ignores_none():
    assert safe_avg([1.0, None, 3.0]) == 2.0


def test_safe_avg_all_none():
    assert safe_avg([None, None]) is None


def test_safe_avg_empty():
    assert safe_avg([]) is None
