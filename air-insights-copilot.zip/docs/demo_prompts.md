# Demo Prompts — Air & Insights Copilot

1) “What’s the PM2.5 and temperature around 42.6977, 23.3219 for the next 6 hours and should I run outdoors?”

2) “Show today’s NASA APOD and summarize in 2 lines.”
