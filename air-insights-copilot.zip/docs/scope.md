# Scope (EN)

## In scope
- REST API:
  - `POST /analyze` → `{ pm25_avg, pm10_avg, temp_avg, guidance_text }`
  - `GET /apod/today` (optional) → `{ title, url, explanation }`
- Agentic flow:
  - plan → fetch Open-Meteo → validate → compute averages → cache (10 min) → LLM reasoning → respond
- Retry/backoff + timeouts
- Unit tests + integration test with stubbed external calls
- Attribution in responses: `Weather data by Open-Meteo.com`

## Out of scope (for MVP)
- User authentication
- Persistent databases / distributed cache
- City-name geocoding (only lat/lon for MVP)
