# Project Plan (BG): Agentic “Air & Insights Copilot”

Този документ е **проектен план с проследяване на прогреса** за задачата “Agentic Air & Insights Copilot”.

## Цел на проекта
Да изградим **agentic assistant** (с планиране, tool use, кеш, валидиране, retry/backoff), който:
- извлича **време + качество на въздуха** от **Open-Meteo (без ключ)**,
- (по избор) извлича **NASA APOD**,
- използва **GitHub Models (free inference)** за да генерира **actionable guidance**,
- предоставя **REST API + OpenAPI 3.0**, пригодно за Copilot Studio Tool/Action или за безплатен UI.

---

## 0) Легенда за статуси
Използвай един от следните статуси:

- ⬜ **Not Started**
- 🟨 **In Progress**
- 🟥 **Blocked**
- 🟩 **Done**

---

## 1) Какво е необходимо, за да започнеш (Prerequisites)

### 1.1 Локална среда
- Python **3.10+** (препоръчително 3.11)
- `git`
- Terminal / PowerShell
- (по избор) Docker

### 1.2 Ключове / достъп
- **GitHub token (PAT)** за GitHub Models inference
- (по избор) **NASA_API_KEY** или ползвай `DEMO_KEY`

### 1.3 Технически решения (минимум)
- Избор на track:
  - **Track B (препоръчително старт)**: FastAPI + web/CLI UI
  - Track A: Copilot Studio Tool/Action (след като API-то е стабилно)
- Език на `guidance_text`: EN или BG (препоръка: EN за Copilot Studio, но може и BG)

### 1.4 Definition of Done (минимум)
- `POST /analyze` приема: `{ latitude, longitude, hours }` и връща:
  `{ pm25_avg, pm10_avg, temp_avg, guidance_text }`
- (optional) `GET /apod/today` връща `{ title, url, explanation }`
- Agentic flow: **plan → fetch → validate → cache (10 мин) → reason (LLM) → respond**
- Retry/backoff + timeouts
- Unit tests (validation + averages) + integration test със stub-нати външни calls
- Логване (request logging + error traces)
- Attribution: **“Weather data by Open-Meteo.com”** в отговора

---

## 2) План по фази (Step-by-step)

> Колоната **Dependencies** казва какво трябва да е готово преди стъпката.

| ID | Стъпка | Защо (накратко) | Dependencies | Output/Deliverable | Status | DoD (готово когато…) |
|---:|--------|------------------|-------------|---------------------|--------|----------------------|
| 1 | Kickoff: потвърди обхват, Track, DoD | Да няма разминаване | — | `docs/scope.md` + DoD | ⬜ Not Started | Ясни цели, endpoints, track, UI |
| 2 | Repo + структура (service/agent/tests/docs/ui) | Чиста поддръжка | ID 1 | Repo skeleton | ⬜ Not Started | Папките/файловете са готови |
| 3 | Dev env + зависимости + `.env` слой | Повторяем старт | ID 2 | `requirements.txt`, `.env.example` | ⬜ Not Started | `pip install` + старт работи |
| 4 | API контракт (Pydantic модели) | Валидира input + OpenAPI | ID 3 | `service/schemas.py` | ⬜ Not Started | `hours` е [1..72], модели са точни |
| 5 | Service endpoints: `/analyze` (+ `/apod/today`) | Основна функционалност | ID 4 | `service/routes.py` | ⬜ Not Started | Swagger показва endpoints |
| 6 | Open-Meteo tools (air + weather) | Free data source | ID 3 | `agent/tools/open_meteo.py` | ⬜ Not Started | Връщат валиден JSON при реален call |
| 7 | Retry/backoff wrapper | Устойчивост | ID 3 | `agent/retry.py` | ⬜ Not Started | Има retries при 429/5xx |
| 8 | Валидиране (lat/lon + payload shape) | Quality gates | ID 4–7 | `agent/validate.py` | ⬜ Not Started | Грешните inputs дават 4xx, sparse → флаг |
| 9 | Изчисления (safe averages) | Правилна статистика | ID 8 | `agent/compute.py` | ⬜ Not Started | None-safe; стабилно при missing |
| 10 | Cache (TTL 10 мин) | Скорост + по-малко calls | ID 3 | `agent/cache.py` | ⬜ Not Started | Cache hit/miss работи |
| 11 | Planner (минимален) | “Agent feel” | ID 8 | `agent/planner.py` | ⬜ Not Started | Връща plan за нужните tools/vars |
| 12 | GitHub Models LLM tool | Reasoning + guidance | ID 3 | `agent/tools/github_models_llm.py` | ⬜ Not Started | Връща текст; има fallback |
| 13 | Prompt library | Консистентни отговори | ID 12 | `agent/prompts/*` | ⬜ Not Started | Guidance е actionable + кратко оправдание |
| 14 | Orchestrator flow (plan→fetch→validate→cache→LLM) | Агентско поведение | ID 6–13 | `agent/orchestrator.py` | ⬜ Not Started | `/analyze` работи E2E |
| 15 | Attribution enforcement | Условие на задачата | ID 14 | общо правило | ⬜ Not Started | Във всеки отговор има attribution |
| 16 | Web UI или CLI (Track B) | Демонстрация | ID 14 | `ui/` | ⬜ Not Started | Може да задаваш lat/lon/hours и да виждаш резултат |
| 17 | Тестове: unit (validate/avg) | Quality gates | ID 8–9 | `tests/test_*.py` | ⬜ Not Started | `pytest` минава |
| 18 | Тест: integration със stub на външни calls | Без flaky тестове | ID 14 | `tests/test_integration_analyze.py` | ⬜ Not Started | Тества без реални HTTP заявки |
| 19 | Логване/observability | Дебъг | ID 14 | structured logging | ⬜ Not Started | Има request_id, traces |
| 20 | Performance check (p95 <2s cached) | Изискване | ID 10 + 14 | simple benchmark | ⬜ Not Started | Cached requests ~ <2s p95 |
| 21 | Export OpenAPI 3.0 файл | Copilot import | ID 5 | `service/openapi.json` | ⬜ Not Started | OpenAPI е наличен/commit-нат |
| 22 | Docs: README + runbook | Стартиране и поддръжка | ID 16–21 | `docs/README.md` | ⬜ Not Started | Нов човек може да подкара локално |
| 23 | Copilot Studio snippet (Track A) | Tool описания | ID 21 | `docs/copilot_tool_snippet.md` | ⬜ Not Started | Copy/paste-ready tool description |
| 24 | Screenshots (Track B UI) | Deliverable | ID 16 | `screenshots/` | ⬜ Not Started | Поне 2–3 screenshots |
| 25 | Track A (ако се прави): import OpenAPI + orchestration | Реална интеграция | ID 21 + Copilot access | Copilot config | ⬜ Not Started | Copilot tool се вика в чат |
| 26 | Final review + release | Завършване | Всички | release artifact | ⬜ Not Started | Всички deliverables са налични |

---

## 3) MVP път (най-бързо работещо)

Препоръчителен MVP ред (Track B):
1 → 2 → 3 → 4 → 5 → 6 → 7 → 8 → 9 → 10 → 12 → 13 → 14 → 15 → 16 → 17 → 18 → 22 → 24 → 21

---

## 4) Рискове и мерки (за начинаещи)
- **Външни API грешат (429/5xx)** → retry/backoff, timeouts
- **Данни липсват/са sparse** → validate flags + “uncertainty” в текста
- **LLM пада/бави** → fallback guidance, отделен timeout
- **Copilot не вика tool-а** → по-добро tool описание + ясни input/output примери в snippet-а

---
