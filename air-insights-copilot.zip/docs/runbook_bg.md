# Runbook (BG) — Air & Insights Copilot

## Оперативни настройки
- CACHE_TTL_SECONDS: 600 (10 мин)
- HTTP_TIMEOUT_SECONDS: ~1.0 (за Open-Meteo)
- LLM_TIMEOUT_SECONDS: ~1.5

## Логване
Препоръка:
- log request_id, latency (air, weather, llm), cache hit/miss
- log exceptions със stack trace

## Поведение при грешки
- Ако Open-Meteo fail-не: връщай 502/503 с message “upstream unavailable”
- Ако LLM fail-не: върни fallback guidance (rule-based)

## Performance цел
- Cached p95 < 2s (in-memory TTL cache обикновено е много по-бърз)

## Security
- Не логвай secrets (.env)
- Няма PII — работи само с lat/lon и публични данни
