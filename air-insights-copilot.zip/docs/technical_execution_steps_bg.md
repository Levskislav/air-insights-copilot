# Technical Execution Steps (BG) — Air & Insights Copilot

Този файл е **практически runbook**: какво точно да направиш, къде и как, за да реализираш проекта.

> Цел: **Track B първо** (FastAPI + web/CLI демо), като API-то остава същото за Copilot Studio (Track A).

---

## 1) Създай repo и структура

```bash
mkdir air-insights-copilot
cd air-insights-copilot
git init

mkdir -p service agent/{prompts,tools} ui/web tests docs screenshots
touch requirements.txt .env.example .gitignore
touch service/{__init__.py,main.py,routes.py,schemas.py}
touch agent/{__init__.py,orchestrator.py,planner.py,validate.py,compute.py,cache.py,retry.py}
touch agent/prompts/{guidance_system.txt,guidance_user_template.txt}
touch agent/tools/{open_meteo.py,nasa_apod.py,github_models_llm.py}
touch ui/web/{index.html,app.js,styles.css}
touch docs/{README.md,copilot_tool_snippet.md,runbook.md}
touch tests/{test_validate.py,test_compute.py,test_integration_analyze.py}
```

---

## 2) Зависимости

**requirements.txt**
```txt
fastapi>=0.110
uvicorn[standard]>=0.27
httpx>=0.27
python-dotenv>=1.0
cachetools>=5.3
pytest>=8.0
```

Инсталирай:
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -U pip
pip install -r requirements.txt
```

---

## 3) `.env` конфигурация

**.env.example**
```env
GITHUB_MODELS_TOKEN=replace_me
GITHUB_MODELS_MODEL=replace_me

NASA_API_KEY=DEMO_KEY

CACHE_TTL_SECONDS=600
HTTP_TIMEOUT_SECONDS=1.0
LLM_TIMEOUT_SECONDS=1.5
```

Създай `.env`:
```bash
cp .env.example .env
```

---

## 4) Схеми (service/schemas.py)

**service/schemas.py**
```python
from pydantic import BaseModel, Field

class AnalyzeRequest(BaseModel):
    latitude: float
    longitude: float
    hours: int = Field(ge=1, le=72)

class AnalyzeResponse(BaseModel):
    pm25_avg: float | None
    pm10_avg: float | None
    temp_avg: float | None
    guidance_text: str

class ApodResponse(BaseModel):
    title: str
    url: str
    explanation: str
```

---

## 5) FastAPI app + endpoints

**service/main.py**
```python
from fastapi import FastAPI
from service.routes import router

app = FastAPI(title="Air & Insights Copilot", version="0.1.0")
app.include_router(router)
```

**service/routes.py**
```python
from fastapi import APIRouter
from service.schemas import AnalyzeRequest, AnalyzeResponse, ApodResponse
from agent.orchestrator import analyze_air_and_weather, apod_today

router = APIRouter()

@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze(req: AnalyzeRequest):
    return await analyze_air_and_weather(req.latitude, req.longitude, req.hours)

@router.get("/apod/today", response_model=ApodResponse)
async def apod():
    return await apod_today()
```

---

## 6) Retry/backoff helper

**agent/retry.py**
```python
import asyncio
import httpx

RETRY_STATUS = {429, 500, 502, 503, 504}

async def request_with_retry(method: str, url: str, *, params=None, headers=None, json=None, timeout: float = 1.0):
    delays = [0.2, 0.5, 1.2]
    last_err = None
    for i in range(len(delays) + 1):
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                r = await client.request(method, url, params=params, headers=headers, json=json)
            if r.status_code in RETRY_STATUS:
                raise RuntimeError(f"retryable http status {r.status_code}")
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last_err = e
            if i < len(delays):
                await asyncio.sleep(delays[i])
            else:
                raise last_err
```

---

## 7) Open-Meteo tools

**agent/tools/open_meteo.py**
```python
from agent.retry import request_with_retry
import os

AIR_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"
WX_URL  = "https://api.open-meteo.com/v1/forecast"

async def fetch_air_quality(lat: float, lon: float, hours: int):
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": "pm2_5,pm10",
        "forecast_hours": hours,
        "timezone": "auto"
    }
    timeout = float(os.getenv("HTTP_TIMEOUT_SECONDS", "1.0"))
    return await request_with_retry("GET", AIR_URL, params=params, timeout=timeout)

async def fetch_weather(lat: float, lon: float, hours: int):
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": "temperature_2m",
        "forecast_hours": hours,
        "timezone": "auto"
    }
    timeout = float(os.getenv("HTTP_TIMEOUT_SECONDS", "1.0"))
    return await request_with_retry("GET", WX_URL, params=params, timeout=timeout)
```

---

## 8) NASA APOD tool (по избор)

**agent/tools/nasa_apod.py**
```python
from agent.retry import request_with_retry
import os

APOD_URL = "https://api.nasa.gov/planetary/apod"

async def fetch_apod_today():
    key = os.getenv("NASA_API_KEY", "DEMO_KEY")
    params = {"api_key": key}
    timeout = float(os.getenv("HTTP_TIMEOUT_SECONDS", "1.0"))
    return await request_with_retry("GET", APOD_URL, params=params, timeout=timeout)
```

---

## 9) Валидиране

**agent/validate.py**
```python
from dataclasses import dataclass

@dataclass
class QualityFlags:
    sparse_air: bool = False
    sparse_weather: bool = False
    missing_fields: list[str] = None

def validate_lat_lon(lat: float, lon: float):
    if lat < -90 or lat > 90:
        raise ValueError("latitude out of range [-90..90]")
    if lon < -180 or lon > 180:
        raise ValueError("longitude out of range [-180..180]")

def _get_hourly_array(payload: dict, key: str):
    hourly = payload.get("hourly") if isinstance(payload, dict) else None
    if not hourly or key not in hourly:
        return None
    return hourly.get(key)

def validate_open_meteo_payload(air_json: dict | None, wx_json: dict | None, hours: int):
    flags = QualityFlags(missing_fields=[])

    pm25 = pm10 = temp = None

    if air_json:
        pm25 = _get_hourly_array(air_json, "pm2_5")
        pm10 = _get_hourly_array(air_json, "pm10")
        if pm25 is None: flags.missing_fields.append("pm2_5")
        if pm10 is None: flags.missing_fields.append("pm10")
        flags.sparse_air = (not pm25) or (len(pm25) < 1)

    if wx_json:
        temp = _get_hourly_array(wx_json, "temperature_2m")
        if temp is None: flags.missing_fields.append("temperature_2m")
        flags.sparse_weather = (not temp) or (len(temp) < 1)

    pm25 = pm25[:hours] if pm25 else pm25
    pm10 = pm10[:hours] if pm10 else pm10
    temp = temp[:hours] if temp else temp

    return {"pm25": pm25, "pm10": pm10, "temp": temp}, flags
```

---

## 10) Safe averages

**agent/compute.py**
```python
def safe_avg(values: list[float | None] | None) -> float | None:
    if not values:
        return None
    nums = [v for v in values if v is not None]
    if not nums:
        return None
    return sum(nums) / len(nums)
```

---

## 11) Cache (TTL 10 мин)

**agent/cache.py**
```python
from cachetools import TTLCache
import os

TTL = int(os.getenv("CACHE_TTL_SECONDS", "600"))
_cache = TTLCache(maxsize=1024, ttl=TTL)

def cache_key(lat: float, lon: float, hours: int) -> str:
    return f"{round(lat, 4)}:{round(lon, 4)}:{hours}"

def cache_get(key: str):
    return _cache.get(key)

def cache_set(key: str, value):
    _cache[key] = value
```

---

## 12) Planner

**agent/planner.py**
```python
def plan_for_analyze(lat: float, lon: float, hours: int) -> dict:
    return {"need_air": True, "need_weather": True}
```

---

## 13) GitHub Models LLM tool

**agent/tools/github_models_llm.py**  
(EN вариантът в другия файл може да се копира 1:1 — тук е същата логика)

---

## 14) Prompts

**agent/prompts/guidance_system.txt** и **guidance_user_template.txt**  
(виж EN файла или напиши BG текст, ако искаш guidance на български)

---

## 15) Orchestrator

**agent/orchestrator.py**  
(копирай версията от EN файла; ключовото е да добавиш attribution)

---

## 16) Стартиране

```bash
uvicorn service.main:app --reload --port 8000
```

---

## 17) Export OpenAPI

```bash
curl -s http://localhost:8000/openapi.json > service/openapi.json
```

---

## 18) Тестове

```bash
pytest -q
```

---
