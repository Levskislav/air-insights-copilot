# Project Plan (EN): Agentic “Air & Insights Copilot”

This is a **step-by-step project plan with progress statuses** for the “Air & Insights Copilot” agent.

## Project goal
Build an **agentic assistant** that:
- fetches **weather + air quality** from **Open-Meteo** (no key),
- optionally fetches **NASA APOD**,
- calls **GitHub Models (free inference)** to synthesize actionable guidance,
- exposes a **REST API + OpenAPI 3.0** suitable for Copilot Studio Tool/Action or a free UI.

---

## 0) Status legend
- ⬜ Not Started
- 🟨 In Progress
- 🟥 Blocked
- 🟩 Done

---

## 1) Prerequisites (to start)

### 1.1 Local environment
- Python 3.10+ (recommended 3.11)
- git
- Terminal
- Optional: Docker

### 1.2 Access/keys
- GitHub PAT for GitHub Models inference
- Optional: NASA_API_KEY or DEMO_KEY

### 1.3 Minimal decisions
- Track choice:
  - Start with **Track B (recommended)**: FastAPI + web/CLI UI
  - Then Track A: Copilot Studio integration
- Guidance language: EN or BG

### 1.4 Definition of Done (minimum)
- `POST /analyze` input: `{ latitude, longitude, hours }` → output: `{ pm25_avg, pm10_avg, temp_avg, guidance_text }`
- Optional: `GET /apod/today` → `{ title, url, explanation }`
- Agentic flow: plan → fetch → validate → cache (10 min) → reason (LLM) → respond
- Retry/backoff + timeouts
- Tests: unit + minimal integration (stub external calls)
- Logging: request + error traces
- Attribution: “Weather data by Open-Meteo.com”

---

## 2) Step-by-step plan

| ID | Step | Why | Dependencies | Output/Deliverable | Status | DoD |
|---:|------|-----|--------------|---------------------|--------|-----|
| 1 | Kickoff: confirm scope, Track, DoD | Align expectations | — | `docs/scope.md` + DoD | ⬜ Not Started | Scope & success criteria agreed |
| 2 | Repo + folders (service/agent/tests/docs/ui) | Maintainability | ID 1 | Repo skeleton | ⬜ Not Started | Structure exists and committed |
| 3 | Dev env + deps + `.env` layer | Repeatable run | ID 2 | requirements + env template | ⬜ Not Started | Install + run works |
| 4 | API schemas (Pydantic) | Validation + OpenAPI | ID 3 | `service/schemas.py` | ⬜ Not Started | Request/response match spec |
| 5 | Service endpoints: `/analyze` (+ `/apod/today`) | Functionality | ID 4 | `service/routes.py` | ⬜ Not Started | Swagger shows endpoints |
| 6 | Open-Meteo tools (air + weather) | Free data | ID 3 | `agent/tools/open_meteo.py` | ⬜ Not Started | Real calls return JSON |
| 7 | Retry/backoff helper | Resilience | ID 3 | `agent/retry.py` | ⬜ Not Started | Retries on 429/5xx |
| 8 | Validation (lat/lon + payload shape) | Quality gates | ID 4–7 | `agent/validate.py` | ⬜ Not Started | Flags sparse/missing data |
| 9 | Compute safe averages | Correct stats | ID 8 | `agent/compute.py` | ⬜ Not Started | None-safe average |
| 10 | Cache (TTL 10 min) | Speed & fewer calls | ID 3 | `agent/cache.py` | ⬜ Not Started | Cache hit/miss works |
| 11 | Planner (minimal) | “Agent feel” | ID 8 | `agent/planner.py` | ⬜ Not Started | Returns plan/tool selection |
| 12 | GitHub Models LLM tool | Guidance reasoning | ID 3 | `agent/tools/github_models_llm.py` | ⬜ Not Started | Returns guidance; has fallback |
| 13 | Prompt library | Consistency | ID 12 | `agent/prompts/*` | ⬜ Not Started | Guidance is actionable and concise |
| 14 | Orchestrator (plan→fetch→validate→cache→LLM) | Agentic flow | ID 6–13 | `agent/orchestrator.py` | ⬜ Not Started | `/analyze` works end-to-end |
| 15 | Attribution enforcement | Requirement | ID 14 | global rule | ⬜ Not Started | Every response includes attribution |
| 16 | Web UI or CLI (Track B) | Demo | ID 14 | `ui/` | ⬜ Not Started | Demo shows computed averages + guidance |
| 17 | Unit tests | Quality | ID 8–9 | `tests/` | ⬜ Not Started | `pytest` passes |
| 18 | Integration test with stubbed tools | Stable CI | ID 14 | `tests/test_integration_analyze.py` | ⬜ Not Started | No real HTTP calls |
| 19 | Logging/observability | Debug | ID 14 | structured logs | ⬜ Not Started | request_id + traces |
| 20 | Performance check (cached p95 <2s) | Requirement | ID 10 + 14 | simple benchmark | ⬜ Not Started | Cached p95 <2s |
| 21 | Export OpenAPI 3.0 file | Copilot import | ID 5 | `service/openapi.json` | ⬜ Not Started | OpenAPI exported and ready |
| 22 | Docs: README + runbook | Usability | ID 16–21 | `docs/README.md` | ⬜ Not Started | New user can run locally |
| 23 | Copilot tool snippet | Track A enablement | ID 21 | `docs/copilot_tool_snippet.md` | ⬜ Not Started | Copy/paste-ready |
| 24 | Screenshots (Track B UI) | Deliverable | ID 16 | `screenshots/` | ⬜ Not Started | 2–3 screenshots |
| 25 | Track A: import OpenAPI + orchestration | Integration | ID 21 + Copilot access | Copilot config | ⬜ Not Started | Tool called in chat |
| 26 | Final review + release | Finish | All | release artifact | ⬜ Not Started | All deliverables present |

---

## 3) Fast MVP path
1 → 2 → 3 → 4 → 5 → 6 → 7 → 8 → 9 → 10 → 12 → 13 → 14 → 15 → 16 → 17 → 18 → 22 → 24 → 21

---
