import json
import asyncio
from dotenv import load_dotenv

from agent.orchestrator import analyze_air_and_weather

load_dotenv()

async def main():
    lat = float(input("latitude: ").strip() or "42.6977")
    lon = float(input("longitude: ").strip() or "23.3219")
    hours = int(input("hours (1..72): ").strip() or "6")
    result = await analyze_air_and_weather(lat, lon, hours)
    print(json.dumps(result, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    asyncio.run(main())
